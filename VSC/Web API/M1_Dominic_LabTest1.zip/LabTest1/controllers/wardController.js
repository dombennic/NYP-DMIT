var wardController = {
    wards: [
        {
            num: 1,
            taken: 0
        },
        {
            num: 2,
            taken: 2
        },
        {
            num: 3,
            taken: 1
        },
        {
            num: 4,
            taken: 0
        },
        {
            num: 5,
            taken: 0
        }
    ],
    patients: [
        {
            name: "John",
            nric: "S1234567E",
            email: "john@hotmail.com",
            wardNum: 2
        },
        {
            name: "Tom",
            nric: "S9876543J",
            email: "tom@hotmail.com",
            wardNum: 2
        },
        {
            name: "Winnie",
            nric: "S8877332K",
            email: "winnie@hotmail.com",
            wardNum: 3
        },
    ]
}