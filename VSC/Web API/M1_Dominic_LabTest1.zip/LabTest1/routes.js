var express = require('express');

var routes = function () {
    var router = require('express').Router();

    router.use(express.urlencoded({
        extended: true

    }));

    router.get('/', function(req, res) {
        res.sendFile(__dirname+"/views/index.html");
    });


    router.get('/css/*', function(req, res){
        res.sendFile(__dirname+"/views/"+req.originalUrl);
    });

    router.get('/js/*', function(req, res){
        res.sendFile(__dirname+"/views/"+req.originalUrl);
    });

    router.get('/patients',function(req,res){
        res.send(patients.addPatient());
    })

    router.post('/patients', function(req, res) {
        var data = req.body;
        
        var patients = {
            name: data.name,
            nric: data.nric,
            email: data.email,
            wardNum: data.wardNum
        };
        
        wardController.addPatient(patient); 
        res.redirect('/');    
    });

    return router;

};

module.exports = routes();
