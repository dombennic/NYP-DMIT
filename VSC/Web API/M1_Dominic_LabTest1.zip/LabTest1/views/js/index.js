$(function() {

    $.ajax({
        url: "/patients",
        method: "GET"
    })

        .done(
            function (data){
               
                data.forEach(function (patients) {
                    $(".patients").append(`<article class="patient"> name:${patients.name} <br><br> 
                    nric:${patients.nric}<br><br>
                    email:${patients.email}<br><br>
                    wardNum:${patients.wardNum}<br><br>
                    </article>`);
                });
            } 
        )
        .fail(
            function(err) {
                console.log(err.responseText);
            }
        )

})