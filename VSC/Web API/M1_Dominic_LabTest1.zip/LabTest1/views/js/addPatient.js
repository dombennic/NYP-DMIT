// $(function() {

//     $.ajax({
//         url: "/patients",
//         method: "GET"
//     })

//         .done(
//             function (data){
               
//                 data.forEach(function (patients) {
//                     $(".patients").append(`<article class="patient"> name:${patients.name} <br><br> 
//                     nric:${patients.nric}<br><br>
//                     email:${patients.email}<br><br>
//                     wardNum:${patients.wardNum}<br><br>
//                     </article>`);
//                 });
//             } 
//         )
//         .fail(
//             function(err) {
//                 console.log(err.responseText);
//             }
//         )

// })

$(function() {

function addPatient(name,nric,email,wardNum){
    
    this.patients.push({name:name,nric:nric,email:email,wardNum:wardNum});
    // wardNum + 1;
}


    $.ajax({
        url: "/patients",
        method: "GET"
    })

        .done(
            function (wards){
               
                if(wards.taken < 2) {
                    wards.forEach(function(wards){
                    $("select").append(`<option value=${wards.num}> ${wards.num} </option>`);
                    })
                };
            } 
        )
        .fail(
            function(err) {
                console.log(err.responseText);
            }
        )

})